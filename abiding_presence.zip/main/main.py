from tkinter import *
from PIL import ImageTk, Image
import time

# places include garden, sanctuary, bailey hall, patio, lobby, senior high room, playground, parking lot
global bunny_pic, front_pic, logo_pic, egg_pic, scene_pic, cross_pic, egg_num

def final_display(verse, verse_lines):
    global canvas, cross_pic

    canvas.delete('all')

    img = Image.open('basket.jpg')
    img = img.resize((960, 610))
    cross_pic = ImageTk.PhotoImage(img)
    canvas.create_rectangle(0, 0, 1000, 650, fill="DarkOrchid3")
    canvas.create_image(20, 20, image=cross_pic, anchor='nw')
    canvas.create_text(623, 150, anchor="nw", fill="gray26", font="Helvetica 25", text="You found all the eggs!")
    canvas.create_text(637, 190, anchor="nw", fill="gray26", font="Helvetica 25", text="The hidden verse is:")
    canvas.create_rectangle(640, 270, 930, 270 + verse_lines * 26, fill='green4', outline='gray26')
    canvas.create_text(650, 280, anchor="nw", fill="grey26", font="Helvetica 15", text=verse)
    buttonC1 = canvas.create_oval(675, 510, 900, 570, fill="DarkOrchid3", outline="gray26")
    buttonC2 = canvas.create_text(725, 520, anchor='nw', fill="grey26", font="Helvetica 25", text="Continue")
    canvas.tag_bind(buttonC1, "<Button-1>", home_page)
    canvas.tag_bind(buttonC2, "<Button-1>", home_page)

def found_egg(words, bible_verse, verse_lines, color, egg):
    global canvas, egg_num

    popup1 = canvas.create_rectangle(235, 200, 765, 430, fill="PaleGreen2", outline='gray26')
    popup2 = canvas.create_text(500, 240, fill='gray26', font="Helvetica 25", text='Congrats!')
    popup3 = canvas.create_text(500, 280, fill='gray26', font="Helvetica 25", text='You found an egg with the words:')
    popup4 = canvas.create_text(500, 380, fill='DeepPink3', font="Helvetica 30", text=words)
    canvas.update()
    time.sleep(4)
    for item in [popup1, popup2, popup3, popup4, egg]:
        canvas.delete(item)
    egg_num -= 1
    canvas.create_rectangle(10, 600, 90, 640, outline='gray26', fill='PaleGreen2')
    canvas.create_oval(18, 605, 38, 635, fill=color, outline='gray26')
    canvas.create_text(65, 620, fill='grey26', font='Helvetica 25', text='x ' + str(10 - egg_num))
    if egg_num == 0:
        final_display(bible_verse, verse_lines)

def hunt(place):
    global canvas, scene_pic, egg_num

    canvas.delete('all')

    # garden ----- (2 Corinthians 5:17) Therefore, if anyone is in Christ, the new creation has come: The old has gone, the new is here!
    if place == 'garden':
        verse = ['Therefore, if', 'anyone is', 'in Christ,', 'the new', 'creation', 'has come:', 'The old', 'has gone,', 'the new', 'is here!', '2 Corinthians 5:17']
        positions = ((557, 476), (799, 210), (922, 454), (215, 564), (821, 536), (479, 374), (288, 544), (32, 475), (976, 489), (617, 597))
        img = Image.open('garden.jpg')
        bible_verse = 'Therefore, if anyone is in\nChrist, the new creation has\ncome: The old has gone, the\nnew is here!\n(2 Corinthians 5:17)'
        verse_lines = 5
        color = 'green3'

    # sanctuary ----- (John 11:25) Jesus said to her, "I am the resurrection and the life. Those who believe in me, even though they die, will live.
    elif place == 'sanctuary':
        verse = ['Jesus said', 'to her, "I', 'am the resurrection', 'and the', 'life. Those', 'who believe', 'in me,', 'even though', 'they die,', 'will live.', 'John 11:25']
        positions = ((210, 210, 220, 220), (230, 230, 240, 240), (250, 250, 260, 260), (270, 270, 280, 280), (90, 90, 100, 100), (110, 110, 120, 120), (130, 130, 140, 140), (150, 150, 160, 160), (170, 170, 180, 180), (190, 190, 200, 200))
        img = Image.open('bunny.jfif')
        bible_verse = 'Jesus said to her, "I am\nthe resurrection and the life.\nThose who believe in me, even\nthough they die, will live."\nJohn 11:25'
        verse_lines = 5
        color = 'red2'

    # bailey hall ----- (1 Peter 1:3) Blessed be the God and Father of our Lord Jesus Christ! By his great mercy he has given us a new birth into a living hope through the resurrection of Jesus Christ from the dead,
    elif place == 'bailey_hall':
        verse = ['Blessed be the God', 'and Father of our', 'Lord Jesus Christ!', 'By his great mercy', 'he has given us', 'a new birth into', 'a living hope', 'through the resurrection', 'of Jesus Christ', 'from the dead,', '1 Peter 1:3']
        positions = ((210, 210, 220, 220), (230, 230, 240, 240), (250, 250, 260, 260), (270, 270, 280, 280), (90, 90, 100, 100), (110, 110, 120, 120), (130, 130, 140, 140), (150, 150, 160, 160), (170, 170, 180, 180), (190, 190, 200, 200))
        img = Image.open('bunny.jfif')
        bible_verse = 'Blessed be the God and\nFather of our Lord Jesus\nChrist! By his great mercy\nhe has given us a new\nbirth into a living hope\nthrough the resurrection of\nJesus Christ from the dead.\n1 Peter 1:3'
        verse_lines = 8
        color = 'red2'

    # patio ----- (Philippians 3:10) I want to know Christ and the power of his resurrection and the sharing of his sufferings by becoming like him in his death,
    elif place == 'patio':
        verse = ['I want to', 'know Christ', 'and the power', 'of his', 'resurrection', 'and the sharing', 'of his sufferings', 'by becoming', 'like him in', 'his death.', 'Philippians 3:10']
        positions = ((694, 591), (207, 560), (114, 614), (34, 430), (591, 360), (712, 402), (403, 206), (559, 422), (634, 529), (874, 379))
        img = Image.open('patio.jpg')
        bible_verse = 'I want to know Christ\nand the power of his\nresurrection and the sharing\nof his sufferings by becoming\nlike him in his death,\nPhilippians 3:10'
        verse_lines = 6
        color = 'salmon4'

    # lobby ----- (Luke 24:5) The women were terrified and bowed their faces to the ground, but the men said to them, "Why do you look for the living among the dead? He is not here, but has risen."
    elif place == 'lobby':
        verse = ['The women were', 'terrified and bowed', 'their faces to the', 'ground, but the men', 'said to them,', '"Why do you look', 'for the living', 'among the dead?', 'He is not here,', 'but has risen."', 'Luke 24:5']
        positions = ((210, 210, 220, 220), (230, 230, 240, 240), (250, 250, 260, 260), (270, 270, 280, 280), (90, 90, 100, 100), (110, 110, 120, 120), (130, 130, 140, 140), (150, 150, 160, 160), (170, 170, 180, 180), (190, 190, 200, 200))
        img = Image.open('bunny.jfif')
        bible_verse = 'The women were terrified and\nbowed their faces to the\nground, but the men said\nto them, "Why do you look\nfor the living among the dead?\nHe is not here, but has risen."\nLuke 24:5'
        verse_lines = 7
        color = 'red2'

    # senior high room ----- (1 Corinthians 6:14) And God raised the Lord and will also raise us by his power.
    elif place == 'senior_high':
        verse = ['And', 'God', 'raised', 'the Lord', 'and will', 'also', 'raise', 'us by', 'his', 'power.', '1 Corinthians 6:14']
        positions = ((210, 210, 220, 220), (230, 230, 240, 240), (250, 250, 260, 260), (270, 270, 280, 280), (90, 90, 100, 100), (110, 110, 120, 120), (130, 130, 140, 140), (150, 150, 160, 160), (170, 170, 180, 180), (190, 190, 200, 200))
        img = Image.open('bunny.jfif')
        bible_verse = 'And God raised the Lord\nand will also raise us\nby his power.\n1 Corinthians 6:14'
        verse_lines = 4
        color = 'red2'

    # playground ----- (Luke 24:2-3) They found the stone rolled away from the tomb, but when they entered, they did not find the body of the Lord Jesus.
    elif place == 'playground':
        verse = ['They found', 'the stone', 'rolled away', 'from the tomb,', 'but when they', 'entered, they', 'did not find', 'the body', 'of the', 'Lord Jesus.', 'Luke 24:2-3']
        positions = ((292, 519), (96, 525), (406, 331), (892, 469), (322, 353), (112, 617), (690, 466), (403, 405), (770, 470), (194, 6))
        img = Image.open('playground.jpg')
        bible_verse = 'They found the stone rolled\naway from the tomb, but when\nthey entered, they did not find\nthe body of the Lord Jesus.\nLuke 24:2-3'
        verse_lines = 5
        color = 'bisque'

    # parking lot ----- (Romans 6:9) We know that Christ, being raised from the dead, will never die again; death no longer has dominion over him.
    else:
        verse = ['We know', 'that Christ,', 'being raised', 'from the', 'dead, will', 'never die', 'again; death', 'no longer', 'has dominion', 'over him.', 'Romans 6:9']
        positions = ((902, 517), (508, 467), (248, 372), (904, 364), (396, 416), (846, 300), (982, 589), (230, 306), (266, 502), (610, 378))
        img = Image.open('parking.jpg')
        bible_verse = 'We know that Christ, being\nraised from the dead, will\nnever die again; death no\nlonger has dominion over him.\nRomans 6:9'
        verse_lines = 5
        color = 'salmon1'

    egg_num = 10
    img = img.resize((1000, 650))
    scene_pic = ImageTk.PhotoImage(img)
    canvas.create_image(0, 0, image=scene_pic, anchor='nw')
    canvas.create_rectangle(10, 600, 90, 640, outline='gray26', fill='PaleGreen2')
    canvas.create_oval(18, 605, 38, 635, fill=color, outline='gray26')
    canvas.create_text(65, 620, fill='grey26', font='Helvetica 25', text='x 0')

    egg_box0 = canvas.create_text(positions[0][0], positions[0][1], font='Times 50 bold', fill=color, text='.')
    canvas.tag_bind(egg_box0, '<Button-1>', lambda e: found_egg(verse[0], bible_verse, verse_lines, color, egg_box0))
    egg_box1 = canvas.create_text(positions[1][0], positions[1][1], font='Times 50 bold', fill=color, text='.')
    canvas.tag_bind(egg_box1, '<Button-1>', lambda e: found_egg(verse[1], bible_verse, verse_lines, color, egg_box1))
    egg_box2 = canvas.create_text(positions[2][0], positions[2][1], font='Times 50 bold', fill=color, text='.')
    canvas.tag_bind(egg_box2, '<Button-1>', lambda e: found_egg(verse[2], bible_verse, verse_lines, color, egg_box2))
    egg_box3 = canvas.create_text(positions[3][0], positions[3][1], font='Times 50 bold', fill=color, text='.')
    canvas.tag_bind(egg_box3, '<Button-1>', lambda e: found_egg(verse[3], bible_verse, verse_lines, color, egg_box3))
    egg_box4 = canvas.create_text(positions[4][0], positions[4][1], font='Times 50 bold ', fill=color, text='.')
    canvas.tag_bind(egg_box4, '<Button-1>', lambda e: found_egg(verse[4], bible_verse, verse_lines, color, egg_box4))
    egg_box5 = canvas.create_text(positions[5][0], positions[5][1], font='Times 50 bold', fill=color, text='.')
    canvas.tag_bind(egg_box5, '<Button-1>', lambda e: found_egg(verse[5], bible_verse, verse_lines, color, egg_box5))
    egg_box6 = canvas.create_text(positions[6][0], positions[6][1], font='Times 50 bold', fill=color, text='.')
    canvas.tag_bind(egg_box6, '<Button-1>', lambda e: found_egg(verse[6], bible_verse, verse_lines, color, egg_box6))
    egg_box7 = canvas.create_text(positions[7][0], positions[7][1], font='Times 50 bold', fill=color, text='.')
    canvas.tag_bind(egg_box7, '<Button-1>', lambda e: found_egg(verse[7], bible_verse, verse_lines, color, egg_box7))
    egg_box8 = canvas.create_text(positions[8][0], positions[8][1], font='Times 50 bold', fill=color, text='.')
    canvas.tag_bind(egg_box8, '<Button-1>', lambda e: found_egg(verse[8], bible_verse, verse_lines, color, egg_box8))
    egg_box9 = canvas.create_text(positions[9][0], positions[9][1], font='Times 50 bold', fill=color, text='.')
    canvas.tag_bind(egg_box9, '<Button-1>', lambda e: found_egg(verse[9], bible_verse, verse_lines, color, egg_box9))

    # back arrow
    buttonB = canvas.create_oval(10, 10, 80, 80, fill='tomato', outline='grey26')
    buttonB1 = canvas.create_line(20, 45, 75, 45, width=6, fill="red3")
    buttonB2 = canvas.create_line(22, 45, 40, 25, width=6, fill="red3")
    buttonB3 = canvas.create_line(22, 45, 40, 65, width=6, fill="red3")
    for button in (buttonB, buttonB1, buttonB2, buttonB3):
        canvas.tag_bind(button, "<Button-1>", home_page)

def hunt_intro(place_name, place_function):
    global canvas, egg_pic, root

    canvas.delete('all')

    img = Image.open('egg.jfif')
    img = img.resize((300, 300))
    egg_pic = ImageTk.PhotoImage(img)
    canvas.create_rectangle(0, 0, 1000, 650, fill="PaleTurquoise1")
    canvas.create_image(500, 175, image=egg_pic)
    canvas.create_text(500, 365, fill="gray26", font="Helvetica 30", text="Welcome to the " + place_name + "!")
    canvas.create_text(500, 425, fill="grey26", font="Helvetica 20", text="The goal is to reveal a special Bible verse by finding all ten of the eggs.")
    buttonC1 = canvas.create_oval(400, 500, 600, 550, fill="PaleTurquoise3", outline="gray26")
    buttonC2 = canvas.create_text(500, 525, fill="grey26", font="Helvetica 25", text="Continue")
    canvas.tag_bind(buttonC1, "<Button-1>", lambda e: hunt(place_function))
    canvas.tag_bind(buttonC2, "<Button-1>", lambda e: hunt(place_function))

    # back arrow
    buttonB = canvas.create_oval(10, 10, 80, 80, fill='tomato', outline='grey26')
    buttonB1 = canvas.create_line(20, 45, 75, 45, width=6, fill="red3")
    buttonB2 = canvas.create_line(22, 45, 40, 25, width=6, fill="red3")
    buttonB3 = canvas.create_line(22, 45, 40, 65, width=6, fill="red3")
    for button in (buttonB, buttonB1, buttonB2, buttonB3):
        canvas.tag_bind(button, "<Button-1>", home_page)

def eggs_for_all(e):
    global bunny_pic, canvas

    canvas.delete('all')

    img = Image.open('eden.jpg')
    img = img.resize((1000, 650))
    bunny_pic = ImageTk.PhotoImage(img)
    canvas.create_image(0, 0, image=bunny_pic, anchor='nw')
    canvas.create_rectangle(425, 175, 695, 225, fill='green4', outline='gray26')
    canvas.create_text(560, 200, fill='grey26', font='Helvetica 25', text='Welcome to Eden')
    canvas.create_text(555, 450, fill='grey26', font='Helvetica 15', text='Because every easter egg\nhunt needs an easter egg.')
    canvas.create_text(555, 635, fill='grey26', font='Helvetica 10', text='Brought to you by Lauren Delwiche, pmd7211@gmail.com')

    # back arrow
    buttonB = canvas.create_oval(10, 10, 80, 80, fill='tomato', outline='grey26')
    buttonB1 = canvas.create_line(20, 45, 75, 45, width=6, fill="red3")
    buttonB2 = canvas.create_line(22, 45, 40, 25, width=6, fill="red3")
    buttonB3 = canvas.create_line(22, 45, 40, 65, width=6, fill="red3")
    for button in (buttonB, buttonB1, buttonB2, buttonB3):
        canvas.tag_bind(button, "<Button-1>", home_page)

def home_page(e):
    global front_pic, canvas, root, logo_pic

    # welcome page
    if e == 0:
        img = Image.open('logo.jpg')
        img = img.resize((300, 300))
        logo_pic = ImageTk.PhotoImage(img)
        canvas.create_rectangle(0, 0, 1000, 650, fill="MediumPurple1")
        canvas.create_image(500, 180, image=logo_pic)
        canvas.create_text(500, 375, fill="gray26", font="Helvetica 30", text="Welcome to the Easter Egg Hunt!")
        canvas.create_text(500, 440, fill="grey26", font="Helvetica 20", text="Please note that the window will not resize in order to keep the eggs well hidden.")
        buttonC1 = canvas.create_oval(400, 500, 600, 550, fill="MediumPurple3", outline="gray26")
        buttonC2 = canvas.create_text(500, 525, fill="grey26", font="Helvetica 25", text="Continue")
        canvas.tag_bind(buttonC1, "<Button-1>", home_page)
        canvas.tag_bind(buttonC2, "<Button-1>", home_page)
    # home page
    else:
        canvas.delete('all')

        # set background image
        img = Image.open('egg_front.png')
        img = img.resize((1000, 650))
        front_pic = ImageTk.PhotoImage(img)
        canvas.create_image(0, 0, image=front_pic, anchor='nw')
        canvas.create_rectangle(240, 205, 770, 355, outline="gray26", fill="SteelBlue3")
        buttonEE = canvas.create_text(505, 280, fill='gray26', font="Helvetica 45 bold", text="Abiding Presence\nEaster Egg Hunt!")
        canvas.tag_bind(buttonEE, '<Button-3>', eggs_for_all)

        # button 1 - garden
        buttonBG1 = canvas.create_oval(20, 470, 230, 540, fill="ForestGreen", outline="gray26")
        buttonTXT1 = canvas.create_text(125, 505, fill="gray26", font="Helvetica 25", text="Garden")
        canvas.tag_bind(buttonBG1, "<Button-1>", lambda e: hunt_intro('Garden', 'garden'))
        canvas.tag_bind(buttonTXT1, "<Button-1>", lambda e: hunt_intro('Garden', 'garden'))

        # button 2 - sanctuary
        buttonBG2 = canvas.create_oval(270, 470, 480, 540, fill="ForestGreen", outline="gray26")
        buttonTXT2 = canvas.create_text(375, 505, fill="gray26", font="Helvetica 25", text="Sanctuary")
        canvas.tag_bind(buttonBG2, "<Button-1>", lambda e: hunt_intro('Sanctuary', 'sanctuary'))
        canvas.tag_bind(buttonTXT2, "<Button-1>", lambda e: hunt_intro('Sanctuary', 'sanctuary'))

        # button 3 - bailey hall
        buttonBG3 = canvas.create_oval(520, 470, 730, 540, fill="ForestGreen", outline="gray26")
        buttonTXT3 = canvas.create_text(625, 505, fill='gray26', font="Helvetica 25", text="Bailey Hall")
        canvas.tag_bind(buttonBG3, "<Button-1>", lambda e: hunt_intro('Bailey Hall', 'bailey_hall'))
        canvas.tag_bind(buttonTXT3, "<Button-1>", lambda e: hunt_intro('Bailey Hall', 'bailey_hall'))

        # button 4 - patio
        buttonBG4 = canvas.create_oval(770, 470, 980, 540, fill="ForestGreen", outline="gray26")
        buttonTXT4 = canvas.create_text(875, 505, fill="gray26", font="Helvetica 25", text="Patio")
        canvas.tag_bind(buttonBG4, "<Button-1>", lambda e: hunt_intro('Patio', 'patio'))
        canvas.tag_bind(buttonTXT4, "<Button-1>", lambda e: hunt_intro('Patio', 'patio'))

        # button 5 - lobby
        buttonBG5 = canvas.create_oval(20, 555, 230, 625, fill="ForestGreen", outline="gray26")
        buttonTXT5 = canvas.create_text(125, 590, fill="gray26", font="Helvetica 25", text="Lobby")
        canvas.tag_bind(buttonBG5, "<Button-1>", lambda e: hunt_intro('Lobby', 'lobby'))
        canvas.tag_bind(buttonTXT5, "<Button-1>", lambda e: hunt_intro('Lobby', 'lobby'))

        # button 6 - senior high room
        buttonBG6 = canvas.create_oval(270, 555, 480, 625, fill="ForestGreen", outline="grey26")
        buttonTXT6 = canvas.create_text(375, 590, fill="gray26", font="Helvetica 25", text="Senior High")
        canvas.tag_bind(buttonBG6, "<Button-1>", lambda e: hunt_intro('Senior High', 'senior_high'))
        canvas.tag_bind(buttonTXT6, "<Button-1>", lambda e: hunt_intro('Senior High', 'senior_high'))

        # button 7 - playground
        buttonBG7 = canvas.create_oval(520, 555, 730, 625, fill="ForestGreen", outline="grey26")
        buttonTXT7 = canvas.create_text(625, 590, fill="grey26", font="Helvetica 25", text="Playground")
        canvas.tag_bind(buttonBG7, "<Button-1>", lambda e: hunt_intro('Playground', 'playground'))
        canvas.tag_bind(buttonTXT7, "<Button-1>", lambda e: hunt_intro('Playground', 'playground'))

        # button 8 - parking lot
        buttonBG8 = canvas.create_oval(770, 555, 980, 625, fill="ForestGreen", outline="grey26")
        buttonTXT8 = canvas.create_text(875, 590, fill="grey26", font="Helvetica 25", text="Parking Lot")
        canvas.tag_bind(buttonBG8, "<Button-1>", lambda e: hunt_intro('Parking Lot', 'parking_lot'))
        canvas.tag_bind(buttonTXT8, "<Button-1>", lambda e: hunt_intro('Parking Lot', 'parking_lot'))

root = Tk()
root.geometry('1000x650')
root.title("Abiding Presence Easter Egg Hunt")
canvas = Canvas(width=1000, height=650)
canvas.pack(side='top', fill='both', expand='no')
home_page(0)

# def motion(event):
#     x, y = event.x, event.y
#     print('{}, {}'.format(x, y))
#
# root.bind('<Motion>', motion)

root.mainloop()

# TODO add hints
# TODO hide eggs in pictures
